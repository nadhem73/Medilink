import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;
  loading = false;
  errorMessage = '';
  successMessage = '';
  showPassword = false;
  showConfirmPassword = false;

  bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  genders = [
    { value: 'MALE', label: 'Homme' },
    { value: 'FEMALE', label: 'Femme' },
    { value: 'OTHER', label: 'Autre' }
  ];

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      // Common fields
      firstName:    ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      lastName:     ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      email:        ['', [Validators.required, Validators.email]],
      phone:        ['', [Validators.required, Validators.maxLength(20)]],
      birthDate:    ['', [Validators.required]],
      gender:       ['', [Validators.required]],
      address:      ['', [Validators.required, Validators.maxLength(255)]],
      cin:          ['', [Validators.maxLength(20)]],

      // Patient-specific fields
      bloodGroup:             ['', [Validators.required]],
      height:                 [null],
      weight:                 [null],
      allergies:              [''],
      chronicDiseases:        [''],
      currentTreatments:      [''],
      emergencyContactName:   ['', [Validators.required]],
      emergencyContactPhone:  ['', [Validators.required]],
      insuranceCompany:       [''],
      insuranceNumber:        [''],

      // Security
      password:        ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]],
      acceptTerms:     [false, [Validators.requiredTrue]],

      // Fixed role
      role: ['PATIENT']
    }, { validators: this.passwordMatchValidator });
  }

  // Shortcut getter for template
  get f() {
    return this.registerForm.controls;
  }

  // Password strength
  get passwordStrength(): number {
    const pwd = this.f['password'].value as string;
    if (!pwd) return 0;
    let score = 0;
    if (pwd.length >= 8)  score += 25;
    if (pwd.length >= 12) score += 15;
    if (/[A-Z]/.test(pwd)) score += 20;
    if (/[0-9]/.test(pwd)) score += 20;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 20;
    return Math.min(score, 100);
  }

  get passwordStrengthClass(): string {
    const s = this.passwordStrength;
    if (s < 40) return 'weak';
    if (s < 70) return 'medium';
    return 'strong';
  }

  get passwordStrengthLabel(): string {
    const s = this.passwordStrength;
    if (s < 40) return 'Faible';
    if (s < 70) return 'Moyen';
    return 'Fort';
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }
    return null;
  }

  onSubmit(): void {
    if (this.registerForm.invalid || this.loading) {
      // Mark all touched to show errors
      Object.keys(this.registerForm.controls).forEach(key => {
        this.registerForm.get(key)?.markAsTouched();
      });
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    const { confirmPassword, acceptTerms, ...registerData } = this.registerForm.value;
    const email = registerData.email;
    const password = registerData.password;

    // Étape 1 : Inscription
    this.authService.register(registerData).subscribe({
      next: () => {
        this.successMessage = 'Compte créé avec succès ! Connexion automatique en cours...';
        
        // Étape 2 : Connexion automatique après inscription
        this.authService.login({ email, password }).subscribe({
          next: () => {
            this.loading = false;
            this.successMessage = 'Bienvenue ! Redirection vers votre espace patient...';
            
            // Redirection vers le panel patient après 1.5 secondes
            setTimeout(() => {
              this.router.navigate(['/dashboard/patient']);
            }, 1500);
          },
          error: (loginError) => {
            // Si la connexion automatique échoue, rediriger vers la page de connexion
            this.loading = false;
            this.successMessage = 'Compte créé ! Veuillez vous connecter.';
            setTimeout(() => {
              this.router.navigate(['/auth/login'], { 
                queryParams: { registered: 'true', email: email } 
              });
            }, 2000);
          }
        });
      },
      error: (error) => {
        this.loading = false;
        this.errorMessage = error?.error?.message || 'Une erreur est survenue. Veuillez réessayer.';
      }
    });
  }
}
