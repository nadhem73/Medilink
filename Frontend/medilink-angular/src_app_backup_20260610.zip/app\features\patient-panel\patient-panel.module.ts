import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientPanelRoutingModule } from './patient-panel-routing.module';

@NgModule({
  imports: [CommonModule, PatientPanelRoutingModule]
})
export class PatientPanelModule {}
