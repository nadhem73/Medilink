// angular import
import { Component } from '@angular/core';
import { animate, style, transition, trigger } from '@angular/animations';
import { Router } from '@angular/router';

// bootstrap import
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';

// project import
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ChatUserListComponent } from './chat-user-list/chat-user-list.component';
import { ChatMsgComponent } from './chat-msg/chat-msg.component';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-nav-right',
  standalone: true,
  imports: [SharedModule, ChatUserListComponent, ChatMsgComponent],
  templateUrl: './nav-right.component.html',
  styleUrls: ['./nav-right.component.scss'],
  providers: [NgbDropdownConfig],
  animations: [
    trigger('slideInOutLeft', [
      transition(':enter', [style({ transform: 'translateX(100%)' }), animate('300ms ease-in', style({ transform: 'translateX(0%)' }))]),
      transition(':leave', [animate('300ms ease-in', style({ transform: 'translateX(100%)' }))])
    ]),
    trigger('slideInOutRight', [
      transition(':enter', [style({ transform: 'translateX(-100%)' }), animate('300ms ease-in', style({ transform: 'translateX(0%)' }))]),
      transition(':leave', [animate('300ms ease-in', style({ transform: 'translateX(-100%)' }))])
    ])
  ]
})
export class NavRightComponent {
  // public props
  visibleUserList: boolean;
  chatMessage: boolean;
  friendId!: number;
  currentUser$: typeof this.authService.currentUser$;

  // constructor
  constructor(
    private authService: AuthService,
    private router: Router,
    config: NgbDropdownConfig
  ) {
    this.visibleUserList = false;
    this.chatMessage = false;
    this.currentUser$ = this.authService.currentUser$;
    config.placement = 'auto';
  }

  // public method
  // eslint-disable-next-line
  onChatToggle(friendID: any) {
    this.friendId = friendID;
    this.chatMessage = !this.chatMessage;
  }

  logout(event?: Event) {
    event?.preventDefault();
    event?.stopPropagation();
    this.authService.logout();
    this.router.navigateByUrl('/');
  }

  // Renvoie l'URL de la photo de profil si elle existe, sinon null
  // eslint-disable-next-line
  avatarOf(user: any): string | null {
    const url = user?.imageUrl || user?.avatarUrl || user?.photoUrl || user?.photo || null;
    return typeof url === 'string' && url.trim().length > 0 ? url : null;
  }

  // Renvoie la premiere lettre du prenom (ou de l'email) en majuscule
  // eslint-disable-next-line
  initialOf(user: any): string {
    const source = (user?.firstName || user?.lastName || user?.email || '').trim();
    return source ? source.charAt(0).toUpperCase() : 'U';
  }
}
