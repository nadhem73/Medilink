import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainLayoutComponent } from './layouts/main-layout/main-layout.component';
import { AuthLayoutComponent } from './layouts/auth-layout/auth-layout.component';
import { DashboardLayoutComponent } from './layouts/dashboard-layout/dashboard-layout.component';
import { authGuard } from './core/guards/auth.guard';

const routes: Routes = [
  // Routes publiques avec MainLayout
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('./features/home/home.module').then(m => m.HomeModule)
      }
    ]
  },
  
  // Routes d'authentification avec AuthLayout
  {
    path: 'auth',
    component: AuthLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('./features/auth/auth.module').then(m => m.AuthModule)
      }
    ]
  },
  
  // Routes des panels avec DashboardLayout (protégées)
  {
    path: 'dashboard',
    children: [
      {
        path: '',
        component: DashboardLayoutComponent,
        children: [
          {
            path: 'patient',
            canActivate: [authGuard],
            loadChildren: () => import('./features/patient/patient.module').then(m => m.PatientModule)
          },
          {
            path: 'doctor',
            loadChildren: () => import('./features/doctor/doctor.module').then(m => m.DoctorModule)
          },
          {
            path: 'pharmacy',
            loadChildren: () => import('./features/pharmacy/pharmacy.module').then(m => m.PharmacyModule)
          },
          {
            path: 'laboratory',
            loadChildren: () => import('./features/laboratory/laboratory.module').then(m => m.LaboratoryModule)
          },
          {
            path: 'ambulance',
            loadChildren: () => import('./features/ambulance/ambulance.module').then(m => m.AmbulanceModule)
          }
        ]
      }
    ]
  },
  
  // Redirect vers home si route non trouvée
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      anchorScrolling: 'enabled',
      scrollPositionRestoration: 'enabled'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
